                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2741201
TronXY E3D v6 plus BLTouch plus 40mm Part Cooling Fan by roycruse is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

A mount for the E3D v6 plus the BLTouch plus a 40mm part cooling fan.

remixed from a couple of other things...

Note:  this will move the hotend forward by about 15mm which does interfere with the travel limits of the y axis.   You will loose about 10mm of print area at the back of the bed.

This is easily fixed by loosening the T nuts and sliding the vertical sections of the frame back by about 25mm (i moved it this far as i believe the design of the x3 the uprights are too far forward anyway).  This will require drilling 2 new 5mm holes for the bolts that go into the base of the uprights from under the printer.

# Print Settings

Printer: TronXY X3A
Rafts: No
Supports: Yes
Resolution: 0.2
Infill: 50%